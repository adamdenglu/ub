#include <vector>
#include <map>
#include <algorithm>
#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
using namespace Rcpp;
using namespace std;


double psi_l_c( double x, double xi, double hl){
  // finite-element basis functions
  double res = 0;

  if((xi - hl < x) && (x <= xi))
  {
    res = ( x - xi + hl ) / hl;
  }
  else if((xi < x) && (x <= xi + hl))
  {
    res = ( xi + hl - x ) / hl;
  }
  else
  {
    res = 0;
  }

  return res;
}


// double inte_u_hat_c( double a, double b, arma::colvec u, arma::colvec sigma_k){
//   // integration of u_hat on [a,b]
//   int k_dim = u.n_rows;
//   double inte = 0.15 * ( b - a );
//   for (int ii=0; ii<k_dim; ii++){
//     if((ii+1)%2==1)
//     {
//       inte = inte-u(ii)*sigma_k(ii)*(cos((ii+1)*PI*b)-cos((ii+1)*PI*a))/((ii+1)*PI);
//     }
//     else
//     {
//       inte = inte+u(ii)*sigma_k(ii)*(sin((ii+1)*PI*b)-sin((ii+1)*PI*a))/((ii+1)*PI);
//     }
//   }
//
//   return inte;
// }


arma::colvec pde_solver_base_c(double u, arma::colvec sigma_k, int l, int small_k){
    // solve for p^l
    int dim_l = pow(2, l + small_k) - 1;
    double h_l = pow(2, -l - small_k);
    arma::colvec xi(dim_l + 1, arma::fill::ones);
    for (int i=0; i<(dim_l+1); i++){
        xi(i) = h_l*(i+1);
    }

    // calculate vector f^l : f^l_i = < f , \psi^l_i >
    arma::colvec f_l(dim_l, arma::fill::zeros);
    for (int i=0; i<dim_l; i++){
        f_l(i) = (u/h_l)* 0.5 *(pow(xi(i)+h_l,2)+pow(xi(i)-h_l,2)-2*pow(xi(i),2));
    }

    // calculate matrix A^l
    // use TDMA to solve equations A^l * p^l = f^l_g
    // store tridiagonal of A^l
    arma::colvec A_l_b(dim_l, arma::fill::zeros);
    arma::colvec A_l_a(dim_l, arma::fill::zeros);
    arma::colvec A_l_c(dim_l, arma::fill::zeros);
    for (int i=0; i<dim_l; i++){
        A_l_b(i) = -2./h_l;
        if(i>0){
            A_l_a(i) = 1./h_l;
            A_l_c(i - 1) = 1./h_l;
        }
    }
    // forward elimination
    arma::colvec c_prime(dim_l, arma::fill::zeros);
    for (int i=0; i<(dim_l-1); i++){
        if(i==0){
            c_prime(i) = A_l_c(i) / A_l_b(i);
        }
        else{
            c_prime(i) = A_l_c(i) / ( A_l_b(i)-A_l_a(i)*c_prime(i - 1) );
        }
    }
    arma::colvec d_prime(dim_l, arma::fill::zeros);
    for (int i=0; i<dim_l; i++){
        if(i==0){
            d_prime(i) = f_l(i) / A_l_b(i);
        }
        else{
            d_prime(i) = (f_l(i) - A_l_a(i)*d_prime(i-1)) / (A_l_b(i) - A_l_a(i)*c_prime(i-1));
        }
    }
    // back substitution
    arma::colvec p_l(dim_l, arma::fill::zeros);
    for (int i=dim_l-1; i>=0; i--){
        if(i==dim_l-1){
            p_l(i) = d_prime(i);
        }
        else{
            p_l(i) = d_prime(i) - c_prime(i)*p_l(i+1);
        }

    }

    return p_l;
}


double pde_solver_c(double x, double u, arma::colvec sigma_k, int l, int small_k, arma::colvec p_l){
    // p^l(x) = \sum_{i=1}^{2^(l+k)-1}p^l_i\Psi_i^l(x)
    double p_sum = 0;
    int dim_l = pow(2, l + small_k) - 1;
    double h_l = pow(2, -l - small_k);
    arma::colvec xi(dim_l + 1, arma::fill::ones);
    for (int i=0; i<(dim_l+1); i++){
        xi(i) = h_l*(i+1);
    }

    for (int i=0; i<dim_l; i++){
        p_sum = p_sum + p_l(i)*psi_l_c(x, xi(i), h_l);
    }

    return p_sum;
}


// [[Rcpp::export]]
double r_l_log_c(double u, arma::colvec sigma_k, int l, int small_k, arma::colvec gp_x, arma::colvec y, double mytheta){
    double ss = 0;
    if(abs(u) > 1){
        ss = -pow(10, 10);
    }
    else{
      arma::colvec p_l = pde_solver_base_c( u , sigma_k , l , small_k );
      int y_n = y.n_rows;
      arma::colvec gp(y_n, arma::fill::zeros);
      for ( int i=0; i<y_n; i++){
        gp(i) = pde_solver_c(gp_x(i), u, sigma_k, l, small_k, p_l);
      }
      arma::mat ss1 = - 0.5 * mytheta * trans( gp - y ) * ( gp - y );
      ss = ss1(0,0);
    }

    return ss;
}



double gaussrand_NORMAL() {
	static double V1, V2, S;
	static int phase = 0;
	double X;
	if (phase == 0) {
		do {
			double U1 = (double) rand() / RAND_MAX;
			double U2 = (double) rand() / RAND_MAX;
			V1 = 2 * U1 - 1;
			V2 = 2 * U2 - 1;
			S = V1 * V1 + V2 * V2;
		} while (S >= 1 || S == 0);
		X = V1 * sqrt(-2 * log(S) / S);
	} else
		X = V2 * sqrt(-2 * log(S) / S);
	phase = 1 - phase;
	return X;
}



double gaussrand(double mean, double stdc) {
	return mean + gaussrand_NORMAL() * stdc;
}



double myunif(double uni_min, double uni_max) {
    bool is_range = true;
    double runif = 0.;
    while( is_range ){
        runif = rand()*1.0/RAND_MAX * (uni_max-uni_min) + uni_min;
        is_range = !( ( runif > uni_min ) && ( runif < uni_max ) );
    }

	return runif;
}


// [[Rcpp::export]]
List sample_eta_0_c(int big_k, int small_k, arma::colvec gp_x, double ini_sigma, int mcmc_len, double theta_0, arma::colvec yt){
  // sample from eta_0 using MCMC
  arma::colvec sigma_k(big_k, arma::fill::ones);
  for (int i=0; i<big_k; i++){
      sigma_k(i) = 0.4 * pow(4, -(i+1));
  }

  // record samples
  arma::colvec ut(mcmc_len, arma::fill::zeros);
  ut(0) = myunif(-1., 1.);  // ~uniform(-1,1)
  arma::colvec accept_record(mcmc_len-1, arma::fill::zeros);
  /* arma::mat random_record(big_k, mcmc_len-1, arma::fill::zeros);
  arma::mat r_l_i_record(big_k, mcmc_len-1, arma::fill::zeros);  */
  for(int i=1; i<mcmc_len; i++){
    double ut_temp = ut(i-1);
    double ut_temp_star = gaussrand(ut_temp, ini_sigma);
    double r_l_i = r_l_log_c(ut_temp_star, sigma_k, 0, small_k, gp_x, yt, theta_0) - r_l_log_c(ut_temp, sigma_k, 0, small_k, gp_x, yt, theta_0);
    double u_i = myunif(0., 1.) ;  // ~uniform(0,1)
    if( log(u_i) <= r_l_i ){
        ut_temp = ut_temp_star;
        accept_record(i-1) = accept_record(i-1) + 1;
    }

    ut(i) = ut_temp;
  }
  double prob_0 = r_l_log_c(ut(mcmc_len-1), sigma_k, 1, small_k, gp_x, yt, theta_0) - r_l_log_c(ut(mcmc_len-1), sigma_k, 0, small_k, gp_x, yt, theta_0);
  double accept_record_ini = mean(accept_record);

  return List::create( Named("samples") = ut(mcmc_len-1),
                       Named("prob") = prob_0,
                       Named("accept") = accept_record_ini);
}


// [[Rcpp::export]]
List mcmc_smc_c(double samples, int l_level, int big_k, int small_k, arma::colvec gp_x, double mcmc_sigma, double theta_0, arma::colvec yt, int mcmc_step){
  // mcmc kernel in smc
  arma::colvec sigma_k(big_k, arma::fill::ones);
  for (int i=0; i<big_k; i++){
      sigma_k(i) = 0.4 * pow(4, -(i+1));
  }

  double sample_candi = samples;
  double accept_record_ll;

  for ( int ll=0; ll<mcmc_step; ll++){
    double sample_candi_star = gaussrand(sample_candi, mcmc_sigma);
    double weights_candi_star = r_l_log_c(sample_candi_star, sigma_k, l_level, small_k, gp_x, yt, theta_0) - r_l_log_c(sample_candi, sigma_k, l_level, small_k, gp_x, yt, theta_0);
    double u_candi = myunif(0., 1.) ;  // ~uniform(0,1)
    if( log(u_candi) <= weights_candi_star ){
        sample_candi = sample_candi_star;
        accept_record_ll = accept_record_ll + 1;
    }
  }
  accept_record_ll = accept_record_ll / double(mcmc_step);

  double prob_ll = r_l_log_c(sample_candi, sigma_k, l_level + 1, small_k, gp_x, yt, theta_0) - r_l_log_c(sample_candi, sigma_k, l_level, small_k, gp_x, yt, theta_0);

  return List::create( Named("samples") = sample_candi,
                       Named("prob") = prob_ll,
                       Named("accept_record_l") = accept_record_ll);
}


// [[Rcpp::export]]
double g_func_inv_c(double u, int big_k, int small_k, arma::colvec gp_x, double theta_0, int l_level , arma::colvec y, double theta_mu, double theta_sigma){
    // g function in inverse problem
    arma::colvec sigma_k(big_k, arma::fill::ones);
    for (int i=0; i<big_k; i++){
        sigma_k(i) = 0.4 * pow(4, -(i+1));
    }
    arma::colvec p_l = pde_solver_base_c(u, sigma_k, l_level, small_k);
    int y_n = y.n_rows;
    arma::colvec gp(y_n, arma::fill::zeros);
    for ( int i=0; i<y_n; i++){
      gp(i) = pde_solver_c(gp_x(i), u, sigma_k, l_level, small_k, p_l);
    }

    // arma::mat ss1 = -0.5 * trans( gp - y ) * ( gp - y ) + (0.5*y_n-1)/theta_0 - (log(theta_0)-theta_mu)/(theta_0*pow(theta_sigma, 2));
    arma::mat ss1 = -0.5 * trans( gp - y ) * ( gp - y ) + (0.5*y_n-1-(log(theta_0)-theta_mu)/pow(theta_sigma, 2))/theta_0 ;
    double ss = ss1(0,0);

    return ss;
}


// [[Rcpp::export]]
double g_func_pap_c(double u, int big_k, int small_k, int l_level , double x_g){
    // g function in paper: g = p(x_g; u)
    arma::colvec sigma_k(big_k, arma::fill::ones);
    for (int i=0; i<big_k; i++){
        sigma_k(i) = 0.4 * pow(4, -(i+1));
    }
    arma::colvec p_l = pde_solver_base_c(u, sigma_k, l_level, small_k);

    double g_x_g = pde_solver_c(x_g, u, sigma_k, l_level, small_k, p_l);
    return g_x_g;
}


// [[Rcpp::export]]
arma::colvec mysum_c(arma::colvec x){
  // sum(x)
  int n = x.n_rows;
  arma::colvec sumx(n, arma::fill::zeros);
  double x_sum = 0;

  for (int i=0; i<n; i++){
    x_sum += x(i);
    sumx(i) = x_sum;
  }
  return sumx;
}


// [[Rcpp::export]]
arma::colvec mymean_c(arma::colvec x){
  // sum(x)
  int n = x.n_rows;
  arma::colvec meanx(n, arma::fill::zeros);

  double x_sum = 0;
  for (int i=0; i<n; i++){
    x_sum += x(i);
    meanx(i) = x_sum / double(i+1);
  }

  return meanx;
}


// arma::colvec tridiagonal_solutaion_c(arma::colvec a, arma::colvec b, arma::colvec c, arma::colvec f){
//   // use TDMA to solve equations A^l * p^l = f^l_g
//   int dim_l = f.n_rows;
//   // forward elimination
//   arma::colvec c_prime(dim_l, arma::fill::zeros);
//   for (int i=0; i<(dim_l-1); i++){
//     if(i==0){
//       c_prime(i) = c(i) / b(i);
//     }
//     else{
//       c_prime(i) = c(i) / ( b(i)-a(i)*c_prime(i - 1) );
//     }
//   }
//   arma::colvec d_prime(dim_l, arma::fill::zeros);
//   for (int i=0; i<dim_l; i++){
//     if(i==0){
//       d_prime(i) = f(i) / b(i);
//     }
//     else{
//       d_prime(i) = (f(i) - a(i)*d_prime(i-1)) / (b(i) - a(i)*c_prime(i-1));
//     }
//   }
//   // back substitution
//   arma::colvec A_inverse_f(dim_l, arma::fill::zeros);
//   for (int i=dim_l-1; i>=0; i--){
//     if(i==dim_l-1){
//       A_inverse_f(i) = d_prime(i);
//     }
//     else{
//       A_inverse_f(i) = d_prime(i) - c_prime(i)*A_inverse_f(i+1);
//     }
//
//   }
//   return A_inverse_f;
// }
//
//
// arma::colvec partial_pde_solver_base_c( arma::colvec u , arma::colvec sigma_k , int l , int small_k, arma::colvec f_l, arma::colvec A_a, arma::colvec A_b, arma::colvec A_c, arma::colvec p_l, int partial_j){
//   // \partial(p^l) / \partial u_j
//   int dim_l = pow(2, l + small_k) - 1;
//   double h_l = pow(2, -l - small_k);
//   arma::colvec xi(dim_l + 1, arma::fill::ones);
//   for (int i=0; i<(dim_l+1); i++){
//     xi(i) = h_l*(i+1);
//   }
//
//   arma::mat partial_A_l(dim_l,dim_l,arma::fill::eye);
//   arma::colvec int_sigma_phi(dim_l+1, arma::fill::zeros);  //\int_{x_{i-1}}^{x_i}\sigma_j\phi_j(x)dx
//   for(int i=0; i<(dim_l+1); i++){
//     if((partial_j+1)%2==1)
//     {
//       int_sigma_phi(i) = -sigma_k(partial_j)*(cos((partial_j+1)*PI*(xi(i) - h_l))-cos((partial_j+1)*PI*xi(i)))/((partial_j+1)*PI);
//     }
//     else
//     {
//       int_sigma_phi(i) = sigma_k(partial_j)*(sin((partial_j+1)*PI*(xi(i) - h_l))-sin((partial_j+1)*PI*xi(i)))/((partial_j+1)*PI);
//     }
//   }
//
//   for(int i=0; i<dim_l; i++){
//     partial_A_l(i,i)=(1./(pow(h_l, 2))) * (int_sigma_phi(i)+int_sigma_phi(i+1));
//     if(i>0)
//     {
//       partial_A_l(i-1,i) = (-1./(pow(h_l, 2))) * int_sigma_phi(i);
//       partial_A_l(i,i-1) = partial_A_l(i-1,i);
//     }
//   }
//
//   arma::colvec tempAl = partial_A_l * p_l;
//   arma::colvec partial_p_l = tridiagonal_solutaion_c(A_a, A_b, A_c, tempAl);
//   return partial_p_l;
// }
//
//
// arma::colvec partial_pde_solver_c( double x, arma::colvec u, arma::colvec sigma_k, int l, int small_k){
//   // \partialp^l(x)/\partial u_j = \sum_{i=1}^{2^(l+k)-1}\partial p^l_i\Psi_i^l(x)
//   int dim_l = pow(2, l + small_k) - 1;
//   double h_l = pow(2, -l - small_k);
//   arma::colvec xi(dim_l + 1, arma::fill::ones);
//   for (int i=0; i<(dim_l+1); i++){
//     xi(i) = h_l*(i+1);
//   }
//
//   // calculate vector f^l : f^l_i = < f , \psi^l_i >
//   arma::colvec f_l(dim_l, arma::fill::zeros);
//   for (int i=0; i<dim_l; i++){
//     f_l(i) = (1/h_l)*(100./6.)*(pow(xi(i)+h_l,3)+pow(xi(i)-h_l,3)-2*pow(xi(i),3));
//   }
//
//   // calculate matrix A^l
//   // use TDMA to solve equations A^l * p^l = f^l_g
//   // store tridiagonal of A^l
//   arma::colvec inte_u_hat_store(dim_l+1, arma::fill::zeros);
//   for (int i=0; i<(dim_l+1); i++ ){
//     inte_u_hat_store(i) = inte_u_hat_c( xi(i) - h_l , xi(i) , u , sigma_k );
//   }
//   arma::colvec A_l_b(dim_l, arma::fill::zeros);
//   arma::colvec A_l_a(dim_l, arma::fill::zeros);
//   arma::colvec A_l_c(dim_l, arma::fill::zeros);
//   for (int i=0; i<dim_l; i++){
//     A_l_b(i) = (1/(pow(h_l, 2))) * (inte_u_hat_store(i) + inte_u_hat_store(i + 1));
//     if(i>0){
//       A_l_a(i) = -(1/( pow(h_l,2))) * inte_u_hat_store(i);
//       A_l_c(i - 1) = A_l_a(i);
//     }
//   }
//
//   // p_l = A_l^(-1)*f_l
//   arma::colvec p_l = tridiagonal_solutaion_c(A_l_a, A_l_b, A_l_c, f_l);
//
//   int big_k = u.n_rows;  // dimension of u
//   arma::colvec partial_p(big_k, arma::fill::zeros);
//
//   for(int kk=0; kk<big_k; kk++){
//     arma::colvec partial_p_l_j = partial_pde_solver_base_c(u, sigma_k, l, small_k, f_l, A_l_a, A_l_b, A_l_c, p_l, kk);
//     partial_p(kk) = 0;
//     for (int i=0; i<dim_l; i++){
//       partial_p(kk) = partial_p(kk) + partial_p_l_j(i)*psi_l_c( x, xi(i), h_l);
//     }
//   }
//
//   return partial_p;
// }



/* // [[Rcpp::export]]
double mlsmc_est_c( List samples, arma::colvec weight, int big_k, int small_k, arma::colvec gp_x, double theta_0, int l_level, arma::colvec y ){
    // estimate at level: \eta_l(gG)/\eta_l(G) - \eta_l(g)
    int num_sample = weight.n_rows;
    arma::colvec eta_l_g(num_sample, arma::fill::zeros);
    arma::colvec eta_l_g_1(num_sample, arma::fill::zeros);
    arma::colvec eta_l_g_G(num_sample, arma::fill::zeros);

    // samples.sort();
    list<int>::iterator iter = samples.begin();

    for (int i=0; i<num_sample; i++){
        eta_l_g(i) = g_func_c( advance(iter,i), big_k, small_k, gp_x, theta_0, l_level , y );
        eta_l_g_1(i) = g_func_c( advance(iter,i), big_k, small_k, gp_x, theta_0, l_level-1 , y );
        eta_l_g_G = eta_l_g(i) * exp( weight(i) );
    }

    double est_l = mean( eta_l_g_G ) / mean( exp( weight ) ) - mean( eta_l_g_1 );

    return est_l;
} */

